package idfc_service.approval;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class ApplicationTests {

	@Test
	void contextLoads() {
	}
	
	
	
	 @Test
	    public void main() {
		 Application.main(new String[] {});
	    }


}
