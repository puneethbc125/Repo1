package idfc_service.approval.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import idfc_service.approval.repository.ApprovalRepository;
import idfc_service.approval.repository.LeadRepository;
import idfc_service.approval.request.ApprovalRequest;
import idfc_service.approval.request.ApprovalRequest.Approvals;
import idfc_service.approval.response.MessageBody;
import idfc_service.approval.response.MessageHeader;
import idfc_service.approval.response.MessageResponse;
import idfc_service.approval.service.ApprovalService;




@RunWith(SpringRunner.class)
@WebMvcTest({ApprovalController.class})
public class ApprovalControllerTest {

	@Autowired
    MockMvc mockMvc;
	
	 @Autowired
	    ObjectMapper mapper;
	 
	 @InjectMocks
	 ApprovalController approvalController;
	    
	    @MockBean
	   LeadRepository leadRepository;
	    
	    @MockBean
	   ApprovalRepository approvalRepo;
	    
	    
	    @MockBean
	    private ApprovalService service;
	    
	    
	    @Test
	    public void addOrUpdateApprovals_Sucess() throws JsonProcessingException, Exception
	    {
	    	
	  
	    
	    Approvals approvalData=Approvals.builder().approvalName("Nill cheque").approverName("cluster head").approvalType("Manual").approvalEmailDMSID("xyz@idfc.com").status("approved").build();
	    		
	      List<Approvals> approvalList=new ArrayList<>();
	    		approvalList.add(approvalData);
	    		
	     ApprovalRequest request=ApprovalRequest.builder().leadRefId("1234").approvals(approvalList).build();
	     
	     MessageResponse response = MessageResponse.builder().messageHeader(MessageHeader.builder().code("200").build())
					.messageBody(MessageBody.builder().status("Success").build())
					.build();
	     
	     when(service.saveOrUpdateApprovals(any())).thenReturn(response);
	     
	     
	     mockMvc.perform(
                 MockMvcRequestBuilders.post("/CALead/approvals")
                         .content(this.mapper.writeValueAsString(request))
                         .contentType(MediaType.APPLICATION_JSON)
                         .accept(MediaType.APPLICATION_JSON)
         )
                 .andExpect(status().isOk())
                 
                 .andExpect(content().json("{\r\n"
                 		+ "\"msg_hdr\": {\r\n"
                 		+ "     \"code\":\"200\"\r\n"
                 		+ "     },\r\n"
                 		+ "\"msg_body\": {\r\n"
                 		+ "     \"status\":\"Success\"\r\n"
                 		+ "     }\r\n"
                 		+ "}"));
	    
	    }
	    
	    @Test
	    public void addOrUpdateApprovals_Fail() throws JsonProcessingException, Exception
	    {
	    	
	  
	    
	    Approvals approvalData=Approvals.builder().approvalName("Nill cheque").approverName("cluster head").approvalType("Manual").approvalEmailDMSID("xyz@idfc.com").status("approved").build();
	    		
	      List<Approvals> approvalList=new ArrayList<>();
	    		approvalList.add(approvalData);
	    		
	     ApprovalRequest request=ApprovalRequest.builder().leadRefId("1234").approvals(approvalList).build();
	     
	     MessageResponse response = MessageResponse.builder().messageHeader(MessageHeader.builder().code("400").build())
					.messageBody(MessageBody.builder().status("Fail").build())
					.build();
	     
	     when(service.saveOrUpdateApprovals(any())).thenReturn(response);
	     
	     
	     mockMvc.perform(
                 MockMvcRequestBuilders.post("/CALead/approvals")
                         .content(this.mapper.writeValueAsString(request))
                         .contentType(MediaType.APPLICATION_JSON)
                         .accept(MediaType.APPLICATION_JSON)
         )
                 .andExpect(status().isBadRequest());
	    
	    }
	    
	    
	
}
