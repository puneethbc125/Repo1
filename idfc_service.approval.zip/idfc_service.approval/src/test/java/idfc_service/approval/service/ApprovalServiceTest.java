package idfc_service.approval.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.databind.introspect.TypeResolutionContext.Empty;

import idfc_service.approval.entity.ApprovalEntity;
import idfc_service.approval.entity.LeadEntity;
import idfc_service.approval.repository.ApprovalRepository;
import idfc_service.approval.repository.LeadRepository;
import idfc_service.approval.request.ApprovalRequest;
import idfc_service.approval.request.ApprovalRequest.Approvals;
import idfc_service.approval.response.ErrorMessageResponse;
import idfc_service.approval.response.MessageResponse;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
public class ApprovalServiceTest {

	@Mock
    private LeadRepository leadRepo;
	
	@Mock
	ApprovalRepository approvalRepo;
	
	ApprovalRequest request;
	
	@InjectMocks
	ApprovalService approvalService;
	
	LeadEntity leadEntity;
	ApprovalEntity approval;
	
	public void initTestCase()
	{
		leadEntity=LeadEntity.builder().leadId(123).leadRefId("1234").build();
		
		leadRepo.save(leadEntity);
		
		approval=ApprovalEntity.builder().approvalId(1).approvalName("Nil cheque").approverName("Branch manager").approvalPrfDmsid("abc@idfc.com").approvalType("system").status("pending").leadId(123).build();
		
Approvals approvalData=Approvals.builder().approvalName("Nill cheque").approverName("cluster head").approvalType("Manual").approvalEmailDMSID("xyz@idfc.com").status("approved").build();
		
		List<Approvals> approvalList=new ArrayList<>();
		approvalList.add(approvalData);
		
		request=ApprovalRequest.builder().leadRefId("1234").approvals(approvalList).build();
		
	}
	
	
	
	
	@Test
	public void saveApproval_Success()
	{
		initTestCase();

		when(leadRepo.getLeadIdByLeadRefId(anyString())).thenReturn(Optional.of(leadEntity.getLeadId()));
		
		when(approvalRepo.findByLeadId(anyLong())).thenReturn(Optional.empty());
		
		when(approvalRepo.save(any(ApprovalEntity.class))).thenReturn(approval);
		
		ApprovalEntity savedApproval=approvalRepo.save(approval);
		assertEquals(savedApproval.getApprovalType(), "system");
		
		
		MessageResponse response=approvalService.saveOrUpdateApprovals(request);
		
		assertEquals(response.getMessageHeader().getCode(), "200");
		
		
		
	}
	
	@Test
	public void saveApproval_Fail()
	{
		initTestCase();

		when(leadRepo.getLeadIdByLeadRefId(anyString())).thenReturn(Optional.empty());
		
		MessageResponse response=approvalService.saveOrUpdateApprovals(request);
		
		assertEquals(response.getMessageHeader().getCode(), "404");
		
		
		
	}
	
	
	@Test
	public void updateApproval_Success()
	{
		initTestCase();
		
		approvalRepo.save(approval);
		
		when(leadRepo.getLeadIdByLeadRefId(anyString())).thenReturn(Optional.of(leadEntity.getLeadId()));
		
		when(approvalRepo.findByLeadId(anyLong())).thenReturn(Optional.of(approval));
		
		when(approvalRepo.updateApproval(anyString(), anyString(), anyString(), anyString(), anyString(), anyLong())).thenReturn(1);
		
		
        MessageResponse response=approvalService.saveOrUpdateApprovals(request);
		
		assertEquals(response.getMessageHeader().getCode(), "200");
		
	}
	
	@Test
	public void updateApproval_Fail()
	{
		initTestCase();
		
		approvalRepo.save(approval);
		
		when(leadRepo.getLeadIdByLeadRefId(anyString())).thenReturn(Optional.of(leadEntity.getLeadId()));
		
		when(approvalRepo.findByLeadId(anyLong())).thenReturn(Optional.of(approval));
		
		when(approvalRepo.updateApproval(anyString(), anyString(), anyString(), anyString(), anyString(), anyLong())).thenReturn(0);
		
		
        MessageResponse response=approvalService.saveOrUpdateApprovals(request);
		
		assertEquals(response.getMessageHeader().getCode(), "500");
		
	}
	
	
	@Test
	public void saveOrUpdate_Exception()
	{
		
		
		try {
		
		 MessageResponse response=approvalService.saveOrUpdateApprovals(null);
			
			
		
		}catch(Exception ex)
		{
			assertThat(ex.toString().contains("405"));
		}
		
				
		
	}
	
	
}
