package idfc_service.approval.exceptionHandler;

import java.util.List;

import org.springframework.http.HttpStatus;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import idfc_service.approval.response.ErrorMessageResponse.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApprovalException extends RuntimeException  {

	private static final long serialVersionUID = 1L;

	private HttpStatus code;
	List<APIError> errors;
}
