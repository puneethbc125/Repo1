package idfc_service.approval.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MessageResponse<T> {
	
	@JsonProperty(value = "msg_hdr")
	private MessageHeader messageHeader;
	
	@JsonProperty(value = "msg_body")
	private T messageBody;

	

	
}
