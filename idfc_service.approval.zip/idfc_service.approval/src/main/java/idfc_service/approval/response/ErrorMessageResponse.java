package idfc_service.approval.response;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class ErrorMessageResponse {

	
	private List<APIError> errors;
	
	
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@Builder

	public static class APIError{
		
		private ErrorMessageHeader msg_hdr;
		private ErrorMessageBody msg_body;
	}
	
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@Builder

	public static class ErrorMessageHeader{
		
		private String errorCode;
		private int status;
		private String type;
	}
	
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@Builder

	public static class ErrorMessageBody{
		
		private String message;
		private String detail;
	}
	
	
	
	
	
}

