package idfc_service.approval.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.OptionalLong;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import idfc_service.approval.request.ApprovalRequest;
import idfc_service.approval.response.*;
import idfc_service.approval.response.ErrorMessageResponse.APIError;
import idfc_service.approval.response.ErrorMessageResponse.ErrorMessageBody;
import idfc_service.approval.response.ErrorMessageResponse.ErrorMessageHeader;

import idfc_service.approval.entity.ApprovalEntity;
import idfc_service.approval.entity.LeadEntity;
import idfc_service.approval.exceptionHandler.ApprovalException;
import idfc_service.approval.repository.ApprovalRepository;
import idfc_service.approval.repository.LeadRepository;

@Service
public class ApprovalService {
	
	
	@Autowired
	LeadRepository leadRepo;
	
	@Autowired
	ApprovalRepository approvalRepo;
	
	
	
	public MessageResponse saveOrUpdateApprovals(ApprovalRequest request)
	{
		
		MessageResponse response=null;
		try {
			//System.out.println("lead ref ID=="+request.getLeadRefId());
			Optional<Long> lead=leadRepo.getLeadIdByLeadRefId(request.getLeadRefId());
			//System.out.println("lead=="+lead);
			if(lead.isPresent())
			{
				
				long leadId=lead.get();
				//System.out.println("lead ID=="+leadId);
				
				Optional<ApprovalEntity> approval=approvalRepo.findByLeadId(leadId);
				if(approval.isPresent())
				{
					//update of approval
					int isUpdate=0;
					//System.out.println("length of approval="+request.getApprovals().size());
					for(int i=0;i<request.getApprovals().size();i++)
					{
					 isUpdate=approvalRepo.updateApproval(request.getApprovals().get(i).getApprovalType(),request.getApprovals().get(i).getStatus(),request.getApprovals().get(i).getApprovalEmailDMSID(),request.getApprovals().get(i).getApprovalName(),request.getApprovals().get(i).getApproverName(),leadId);
					}
					if(isUpdate==1)
					response = MessageResponse.builder().messageHeader(MessageHeader.builder().code("200").build())
			 					.messageBody(MessageBody.builder().status("Success").build())
								.build();
					
					else
						response = MessageResponse.builder().messageHeader(MessageHeader.builder().code("500").build())
						.messageBody(MessageBody.builder().status("Update Fail").build())
						.build();
				
				}
				else {
				
					//creation of approval
					ApprovalEntity approvalDetails=null;
					for(int i=0;i<request.getApprovals().size();i++)
					{
						approvalDetails=ApprovalEntity.builder().approvalType(request.getApprovals().get(i).getApprovalType()).status(request.getApprovals().get(i).getStatus()).approvalPrfDmsid(request.getApprovals().get(i).getApprovalEmailDMSID()).approvalName(request.getApprovals().get(i).getApprovalName()).approverName(request.getApprovals().get(i).getApproverName()).leadId(leadId).build();
						approvalRepo.save(approvalDetails);
					}
					
					response = MessageResponse.builder().messageHeader(MessageHeader.builder().code("200").build())
							.messageBody(MessageBody.builder().status("Success").build())
							.build();
					
				}
				
			}
			else {
				
				List<APIError> errors=new ArrayList<ErrorMessageResponse.APIError>();
			    errors.add(ErrorMessageResponse.APIError.builder().msg_hdr(ErrorMessageHeader.builder().errorCode("404").status(0).type("Not Found").build()).msg_body(ErrorMessageBody.builder().message("Lead Ref ID "+request.getLeadRefId()+" Not found").detail("requested lead ref ID not found").build()).build());
			    
			    response = MessageResponse.builder().messageHeader(MessageHeader.builder().code("404").build())
						.messageBody(errors)
						.build();
				
		}
		}catch(Exception e)
		{
			e.printStackTrace();
			
			List<APIError> errors=new ArrayList<ErrorMessageResponse.APIError>();
		    errors.add(ErrorMessageResponse.APIError.builder().msg_hdr(ErrorMessageHeader.builder().errorCode("405").status(0).type("exception").build()).msg_body(ErrorMessageBody.builder().message(e.getMessage()).detail(e.getMessage()).build()).build());
		    
		    throw new ApprovalException(HttpStatus.METHOD_NOT_ALLOWED,errors);

			
		}

		return response;
	}

}
