package idfc_service.approval.repository;




import java.util.Optional;
import java.util.OptionalLong;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import idfc_service.approval.entity.LeadEntity;



@Repository

public interface LeadRepository extends JpaRepository<LeadEntity, Long>{

	@Query("SELECT l.leadId FROM LeadEntity l WHERE l.leadRefId=:leadRefId")
	Optional<Long> getLeadIdByLeadRefId(@Param("leadRefId") String leadRefId);
	
	
	
	
}