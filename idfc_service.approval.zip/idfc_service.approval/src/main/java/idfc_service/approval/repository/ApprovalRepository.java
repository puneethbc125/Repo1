package idfc_service.approval.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import idfc_service.approval.entity.ApprovalEntity;

@Repository
public interface ApprovalRepository extends CrudRepository<ApprovalEntity, Long>{

	Optional<ApprovalEntity> findByLeadId(long leadId);

	@Modifying
	@Transactional
	@Query("update ApprovalEntity approval set approval.approvalType = :_approvalType, approval.status = :_status, approval.approvalPrfDmsid = :_approvalEmailDMSID, approval.approvalName = :_approvalName, approval.approverName = :_approverName  where approval.leadId = :_leadId")
	int updateApproval(@Param(value = "_approvalType") String _approvalType, @Param(value = "_status") String _status,@Param(value = "_approvalEmailDMSID") String _approvalEmailDMSID, @Param(value = "_approvalName") String _approvalName,@Param(value = "_approverName") String _approverName, @Param(value = "_leadId") long _leadId);


}
