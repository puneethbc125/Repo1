package idfc_service.approval.entity;

import java.time.LocalDate;

import javax.persistence.*;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Entity
@Table(name ="LEAD")
public class LeadEntity {
	
	@Id
	@Column(name = "LEAD_ID")
	private long leadId;

	@Column(name = "LEAD_REF_ID")
	private String leadRefId;

	@Column(name = "SFDC_CASE_ID")
	private String sfdcCaseId;

	@Column(name = "PROPRITOR_ID")
	private long propritorId;
	
	@Column(name = "BUSINESS_ENTITY_ID")
	private long businessEntityId;
	
	@Column(name = "STATUS")
	private String status;

	@Column(name = "STAGE")
	private String stage;
	
	@Column(name = "CURR_DATE")
	private LocalDate currDate;
	
	@Column(name = "LEAD_CONVERTOR")
	private String leadConvertor;
	
	@Column(name = "CREATED_DATE")
	private LocalDate createdDate;
	
	@Column(name = "LEAD_GENERATOR")
	private String leadGenerator;
	
	@Column(name = "BANK_STMT_ID")
	private long bankStmtId;
	
	@Column(name = "CREDIT_EXPOSURE")
	private long creditExposure;
	
	@Column(name = "DISPUTE_ID")
	private long disputeId; 
	
	@Column(name = "NOC_DOC_DMSID")
	private String nocDocDmsId;
	
	@Column(name = "MOBILE_NO_EXISTS")
	private int mobileNoExists;
	
	@Column(name = "MOBILE_NO_EXISTS_REASON")
	private String mobileNlExistsReason;
	
	@Column(name = "PRODUCT")
	private String product; 
	
	@Column(name = "ACCOUNT_INFO_ID")
	private long accInfoId;
	
	@Column(name = "FUNDING_ID")
	private long fundingId;
	
	@Column(name = "TRADE_PLANTFORM")
	private int tradePlantform;
	
	@Column(name = "CUST_INFO_FROM_DMSID")
	private String custInfoFromDmsId;
	
	@Column(name = "BARCODE")
	private String barcode; 
	
	@Column(name = "SITE_VER_STATUS")
	private String siteVerStatus; 
	
	@Column(name="SIT_VER_DATE")
	private LocalDate sitVerDate;
	
	@Column(name = "SITE_VER_PHOTO_DMSID")
	private String siteVerPhotoDmsId;

	
	
	
	
	
	
	
	
	
	
	
	
	

	

}
