package idfc_service.approval.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Entity
@Table(name ="APPROVALS")
public class ApprovalEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "approval_seq")
	@SequenceGenerator(name = "approval_seq", sequenceName = "BE_SEQ", allocationSize = 1,initialValue=1)
	private long approvalId;

	@Column(name = "APPROVAL_NAME")
	private String approvalName;
	
	@Column(name = "APPROVER_NAME")
	private String approverName;
	
	@Column(name = "APPROVAL_PRF_DMSID")
	private String approvalPrfDmsid;
	
	@Column(name = "APPROVAL_TYPE")
	private String approvalType;
	
	@Column(name = "STATUS")
	private String status;
	
	@Column(name = "LEAD_ID")
	private long leadId;

}
