package idfc_service.approval.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import idfc_service.approval.request.ApprovalRequest;
import idfc_service.approval.response.MessageResponse;
import idfc_service.approval.service.ApprovalService;



@RestController

@RequestMapping(value = "/CALead")
public class ApprovalController {
	
 @Autowired
 ApprovalService approvalService;
 
@PostMapping(value ="/approvals", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	
	public ResponseEntity<MessageResponse> addOrUpdateApprovals(@RequestBody ApprovalRequest request) {
	
	MessageResponse response =approvalService.saveOrUpdateApprovals(request);
	
	if(response.getMessageHeader().getCode().equals("200"))
		return new ResponseEntity<>(response, HttpStatus.OK);
	else
		return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
	
    }
}
