package idfc_service.approval.request;


import java.util.List;

import idfc_service.approval.response.ErrorMessageResponse;
import idfc_service.approval.response.ErrorMessageResponse.ErrorMessageBody;
import idfc_service.approval.response.ErrorMessageResponse.ErrorMessageHeader;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApprovalRequest {

	private String leadRefId;
	private List<Approvals> approvals;
	
	
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	@Builder
	public static class Approvals{
		
		private String approvalType;
		private String status;
		private String approvalEmailDMSID;
		private String approvalName;
		private String approverName;
	}
	
	
}
